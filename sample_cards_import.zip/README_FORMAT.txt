ANIME CARD COLLECTION BOT — NAMUNA ZIP FORMATI (V2)
=====================================================

1. MAJBURIY 5 TA MAYDON (har bir karta uchun shart, bo'lmasa qo'shilmaydi):
   - "character_name": Personaj ismi (masalan: "Gojo Satoru")
   - "media_type": Media turi — quyidagilardan biri:
        Anime | Manga | Manhwa | Manhua | Comics | Cartoon | Kino | Game | Other
   - "anime_name": Anime/Manga/Kino nomi (masalan: "Jujutsu Kaisen")
   - "rank_id": Doimiy Rank ID raqami (Admin -> Rank bo'limidan olinadi):
        1 = Common (Oddiy)
        2 = Rare (Noyob)
        3 = Super Rare
        4 = Epic
        5 = Mythic
        6 = Divine
        (Izoh: Admin rank nomini o'zgartirsa ham rank_id o'zgarmaydi!)
   - "image": ZIP arxiv ichidagi rasm fayli yo'li (masalan: "images/gojo.png")
              Rasm formati: .jpg, .jpeg, .png, .webp, .gif

2. IXTIYORIY MAYDONLAR:
   - "description": Personaj haqida qisqacha ma'lumot
   - "aliases": Taxallus / qisqa ismlar ro'yxati ["Gojo", "Satoru"]
   - "drop_limit": Guruhlarga nechta tushishi (yozilmasa Rank bo'yicha olinadi)

3. AI UCHUN PROMPT NAMUNASI:
   "Ushbu rasmlar uchun namuna ZIP ichidagi cards.json formatida
    5 ta majburiy maydon (character_name, media_type, anime_name, rank_id, image)
    va description, aliases bilan to'liq JSON tayyorlab ber."
